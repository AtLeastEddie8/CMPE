
Readme: 

The structural mode circuit design uses 2, 3, and 4 input gates. The testbench does not seem 
to handle the 4 input gates as I received errors when using it. I have commented with capital letters
which output uses which wires and gates. The structural mode design works ONLY with 
the multiple gates (2,3,4). I have included a picture of this design in the project submission. Additionally I began implementing the 
testbecnhes and structural modes for each individual output up to segment f.To use these all one has to do is copy them over to putty and
open them using emacs ( or copy paste). 

Edgard Rivera